# CloudStream BocTem Plugin

CloudStream plugin for [BocTem.com](https://boctem.com) - Anime Vietsub streaming.

## Features

- Search anime
- Browse categories (Anime Mới, Anime Hay, Anime Movie)
- Episode list
- Direct m3u8 streaming

## Installation

### Method 1: Repository URL
1. Open CloudStream
2. Go to Settings > Extensions > Add Repository
3. Enter the repository.json URL:
   ```
   https://raw.githubusercontent.com/USER/REPO/Builds/latest/repository.json
   ```

### Method 2: Direct Install
1. Download the `.cs3` file from Releases or Builds branch
2. Open with CloudStream

## Build

```bash
./gradlew make
```

## Structure

```
cloudstream-boctem/
├── BocTem/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml
│       └── kotlin/com/BocTem/
│           ├── BocTem.kt
│           └── BocTemProvider.kt
├── .github/workflows/
│   └── build.yml
├── build.gradle.kts (root)
├── settings.gradle.kts
└── README.md
```

## API Endpoints Used

- `GET /?s={query}` - Search
- `GET /anime-moi/page/{page}` - New anime
- `POST /wp-admin/admin-ajax.php` - Player data (action=halim_ajax_player)

## License

MIT
